import random
import sys
import os
import shutil
import time
from multiprocessing import Process
import multiprocessing
from multiprocessing import Pool
from concurrent.futures import ThreadPoolExecutor,wait,ALL_COMPLETED,FIRST_COMPLETED, as_completed
# import concurrent.futures
# import subprocess
import threading

# 将一行字符串按空格切割
def split(s):
    res = ""
    space = {' ', '\t', '\n', '\r', '\f'}
    ans = []
    for i in s:
        if i in space: 
            if len(res) > 0:
                ans.append(res)
                res = ""
            continue
        res += i
    return res


# 返回命令行参数
def args():
    return sys.argv[1:]

# 读取一个字符串
def next(f):
    res = ''
    space = {' ', '\t', '\n', '\r', '\f'}
    c = f.read(1)
    while c: 
        if (c in space) and len(res):
            return res
        if c not in space:
            res += c
        c = f.read(1)
    return res

# 判断两个文件是否相同
def equals(file1, file2):
    with open(file1, mode='r', encoding='utf-8') as f1, \
        open(file2, mode='r', encoding='utf-8') as f2:
        s1 = next(f1)
        s2 = next(f2)
        while s1 and s2:
            if s1 != s2 :
                return False
            s1 = next(f1)
            s2 = next(f2)
        return not s1 and not s2

# 初始化工作区目录
def init():
    try:
        os.system('if not exist in.txt type nul> in.txt')
        os.system('type nul> out.txt')
        os.system('if not exist res.txt type nul> res.txt')
        os.mkdir('.check')
    except:
        shutil.rmtree('.check')
        os.mkdir('.check')
    # os.system('type nul> .check\\time.txt')
    
def run_func(func, args, qu):
    st = time.time()
    func(*args)
    ed = time.time()
    qu.put(ed - st)

# 统计函数运行耗时，可以限制最长时间
def spand(fun, cmds, ti = -1):
    p = Process(target=fun, args=(*cmds, ))
    p.start()
    pid = p.pid
    # print(p.pid())
    st = time.time()
    while True:
        nw = time.time()
        if not p.is_alive():
            # print('%.3fs' % (nw - st, ), ti)
            return nw - st
        if ti > -1 and nw - st > ti:
            os.system(f'taskkill /f /t /pid {pid} >nul')
            return -1
        
def language(name):
    if name.endswith('.c'): return 'c'
    if name.endswith('.cpp'): return 'cpp'
    if name.endswith('.py'): return 'py'
    if name.endswith('.java'): return 'java'
    return None

def fcopy(name1, name2):
    os.system(f'copy /y {name1} {name2} >nul')

def compiler(name):
    fcopy(name, f'.check\\{name}')
    lg = language(name)
    cmd = ''
    if lg == 'c':
        cmd = f'gcc -w -std=c99 -static .check\\{name} -o .check\\{name[:-2]} -O2 -Wall -Wextra -Wl,--stack=549453824'
    elif lg == 'cpp':
        cmd = f'g++ -w -std=c++20 -static -O2 -Wall -Wextra -Wl,--stack=549453824 .check\\{name} -o .check\\{name[:-4]}'
    elif lg == 'java':
        cmd = f'javac -encoding utf8 .check\\{name}'
    if cmd:
        os.system(cmd)

def run_single(name, ti):
    ti = int(ti)
    qu = multiprocessing.Queue()
    compiler(name)
    lg = language(name)
    qu = multiprocessing.Queue()
    t = None
    if lg == 'c':
        t = spand(run_func, (os.system, (f'.check\\{name[:-2]} <in.txt >out.txt', ), qu), ti)
    elif lg == 'cpp':
        t = spand(run_func, (os.system, (f'.check\\{name[:-4]} <in.txt >out.txt', ), qu), ti)
    elif lg == 'java':
        t = spand(run_func, (os.system, (f'java -cp .check {name[:-5]} <in.txt >out.txt', ), qu), ti)
    else:
        t = spand(run_func, (os.system, (f'python -u .check\\{name} <in.txt >out.txt', ), qu), ti)
    if t == -1:
        print("Time Limit Exceed")
    else:
        if equals('out.txt', 'res.txt'):
            print("Accept -> %.3fs" % qu.get())
        else:
            print("Wrong  -> %.3fs" % qu.get())

def ck_compiler(f1, f2, f3):
    pool = Pool(3)
    pool.apply_async(compiler, (f1, ))
    pool.apply_async(compiler, (f2, ))
    pool.apply_async(compiler, (f3, ))
    pool.close()
    pool.join()

    
def ck_get_run(f):
    lg = language(f)
    if lg == 'c':
        return f'.check\\{f[:-2]}'
    elif lg == 'cpp':
        return f'.check\\{f[:-4]}'
    elif lg == 'java':
        return f'java -cp .check {f[:-5]}'
    else :
        return f'python -u .check\\{f}'

status = 0
rt = []
op = 0
lock = threading.Lock()

def ck_run_and_check(id, f1, f2, f3, ti):
    global status
    global rt
    global op
    if status:
        return
    a = ck_get_run(f1)
    b = ck_get_run(f2)
    c = ck_get_run(f3)
    a += f" >.check\\in_{id}.txt"
    b += f" <.check\\in_{id}.txt >.check\\res_{id}.txt"
    c += f" <.check\\in_{id}.txt >.check\\out_{id}.txt"
    os.system(f'type nul> .check\\in_{id}.txt')
    os.system(f'type nul> .check\\out_{id}.txt')
    os.system(f'type nul> .check\\res_{id}.txt')
    qu = multiprocessing.Queue()
    t = spand(run_func, (os.system, (a, ), qu), 10)
    with lock:
        if status: return
        if t == -1:
            print('Rand Time Limit Exceed')
            status = 3
            return
    t = spand(run_func, (os.system, (b, ), qu), 10)
    with lock:
        if status: return
        if t == -1:
            print('Answer Time Limit Exceed')
            status = 4
            return
    t = spand(run_func, (os.system, (c, ), qu), ti)
    if t == -1:
        with lock:
            if status: return
            status = 2
        return
    if equals(f'.check\\out_{id}.txt', f'.check\\res_{id}.txt'):
        t = qu.get()
        with lock:
            if status: return
            print("Accept -> %.3fs" % t)
            rt.append(t)
    else:
        t = qu.get()
        with lock:
            if status: return
            status = 1
            print("Wrong  -> %.3fs" % t)
            rt.append(t)
            fcopy(f'.check\\in_{id}.txt', 'in.txt')
            fcopy(f'.check\\out_{id}.txt', 'out.txt')
            fcopy(f'.check\\res_{id}.txt', 'res.txt')
    os.remove(f'.check\\in_{id}.txt')
    os.remove(f'.check\\out_{id}.txt')
    os.remove(f'.check\\res_{id}.txt')
    
def check(f1 = "Rand.cpp", f2 = "Answer.cpp", f3 = "Main.cpp", ti = -1, ts = 10):
    ti = int(ti)
    ts = int(ts)
    ck_compiler(f1, f2, f3)
    
    all_task = []
    with ThreadPoolExecutor(max_workers=5) as pool:
        for i in range(1, ts + 1):
            all_task.append(pool.submit(lambda p: ck_run_and_check(*p), (i, f1, f2, f3, ti)))
        wait(all_task, return_when=ALL_COMPLETED)
    
    # print(rt)
    # print(status)
    
    if status == 2:
        print("Time Limit Exceed")
        return
    
    elif status == 1:
        print("----------------\n")
        print("Wrong  -> %.3fs" % max(rt))
    elif status == 0:
        print("----------------\n")
        print("Accept -> %.3fs" % max(rt))
        

if __name__ == '__main__':
    init()
    
    sls = args()
    n = len(sls)
    if n == 0:
        check(ti=10)
    elif n == 1:
        t = language(sls[0])
        if t:
            run_single(sls[0], 10)
        else:
            check(ti=10, ts=int(sls[0]))
    elif n == 2:
        run_single(sls[0], int(sls[1]))
    elif n == 3:
        check(*sls)
    elif n == 4:
        check(sls[0], sls[1], sls[2], ts=int(sls[3]))
    elif n == 5:
        check(sls[0], sls[1], sls[2], ts=int(sls[3]), ti=int(sls[4]))