with open('.out.txt', encoding='gbk', mode='r') as cin, open('out.txt', encoding='utf-8', mode='w') as cout:
    cout.write(cin.read())