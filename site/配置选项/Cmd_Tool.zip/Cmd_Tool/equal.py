import re

def main():
    eof = 0
    with open('res.txt', mode='r', encoding='utf-8') as f1:
        f1.seek(0, 2)
        eof = f1.tell()
        
    with open('res.txt', encoding='utf-8', mode='r') as f1:
        if f1.tell() >= eof: exit()
        with open('out.txt', encoding='utf-8', mode='r') as f2:
            sum = 0
            ls1 = []
            ls2 = []
            for i in f1:
                ls1.append(i)
            for i in f2:
                ls2.append(i)
            for i, j in zip(ls1, ls2):
                sum += 1
                a = re.findall('\S+', i, re.DOTALL)
                b = re.findall('\S+', j, re.DOTALL)
                # print(a)
                # print(b)
                if len(a) != len(b):
                    return sum
                for x, y in zip(a, b):
                    if x != y:
                        return sum
    if len(ls1) != len(ls2):
        return min(len(ls1), len(ls2))
    return 0

t = main()

if t == 0:
    print("Accept")
else:
    print("Error on line %d" % (t))