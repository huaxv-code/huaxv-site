import re
import sys
import os
import time
import signal
from multiprocessing import Process

def main():
    sls = sys.argv
    s = ""
    for i in range(1, len(sls)):
        s += sls[i] + " "
    s = s[:-1]
    
    start = time.time()
    os.system(s)
    end = time.time()
    
    start = int(start * 1000)
    end = int(end * 1000)
    
    print('耗时  %d  ms' % (end - start))
    
if __name__ == '__main__':
    
    p = Process(target=main)
    p.start()
    
    for i in range(500):
        if p.is_alive():
            if os.path.getsize('out.txt') >= 100 * 1024 * 1024:
                if p.is_alive():
                    os.system(f'taskkill /pid {p.pid} -t -f 1>nul 2>nul')
                p.join()
                
                print("输出超限！")
                os.system('type nul > out.txt')
                exit()
            time.sleep(0.01)
        else :
            exit()

    if p.is_alive():
        os.system(f'taskkill /pid {p.pid} -t -f 1>nul 2>nul')
    p.join()
    
    print("运行超时！")
    os.system('type nul> out.txt')
    # g++ Main.cpp -o Main && python -u UseTime.py Main